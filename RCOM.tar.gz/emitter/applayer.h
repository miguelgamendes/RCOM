#ifndef APPLAYER_H
#define APPLAYER_H

#include "llopen.h"
#include "llwrite.h"
#include "llclose.h"

int sendFile(int conn, int file);

#endif
