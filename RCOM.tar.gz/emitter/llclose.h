#ifndef LLCLOSE_H
#define LLCLOSE_H

#include "bytevalues.h"

int llclose(int fd);

#endif
