#define F 0x7E
#define A 0x03
#define C 0x03
#define CS 0x07

int llopen(int fd);