#ifndef APPLAYER_H
#define APPLAYER_H

#include "llopen.h"
#include "llread.h"
#include "llclose.h"

int receiveFile(int conn, int file);

#endif
